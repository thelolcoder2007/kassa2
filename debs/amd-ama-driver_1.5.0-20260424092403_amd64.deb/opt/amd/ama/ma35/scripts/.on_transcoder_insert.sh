#!/bin/bash
# Copyright 2024 Xilinx, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Disable FLR and VF auto-probe
bus_ids=$(lspci -D -d 10ee:5070|cut -d ' ' -f 1|sort)
num_buses=$(echo "$bus_ids" | wc -l)
for bus_id in $bus_ids; do
  reset_method="/sys/bus/pci/devices/$bus_id/reset_method"
  if [ -e "$reset_method" ] && [[ "`cat $reset_method`" != "" ]]; then
    echo ''|tee $reset_method 1>/dev/null
  fi
  vf_auto_probe="/sys/bus/pci/devices/$bus_id/sriov_drivers_autoprobe"
  if [ -e "$vf_auto_probe" ] && [[ "`cat $vf_auto_probe`" != 0 ]]; then
    echo 0|tee $vf_auto_probe 1>/dev/null
  fi
done
